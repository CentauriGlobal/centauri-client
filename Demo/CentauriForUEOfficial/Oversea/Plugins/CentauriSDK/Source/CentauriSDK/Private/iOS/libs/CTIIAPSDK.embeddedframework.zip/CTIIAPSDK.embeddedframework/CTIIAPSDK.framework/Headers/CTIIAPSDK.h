//
//  CTIIAPSDK.h
//  CTIIAPSDK
//
//  Created by seahub on 2020/5/20.
//  Copyright © 2020 CTI. All rights reserved.
//

#ifndef CTIIAPSDK_h
#define CTIIAPSDK_h

#import <CTIIAPSDK/CTIIAPApi.h>
#import <CTIIAPSDK/CTIIAPObject.h>
#import <CTIIAPSDK/CTIIAPPayDelegate.h>

#endif /* CTIIAPSDK_h */
